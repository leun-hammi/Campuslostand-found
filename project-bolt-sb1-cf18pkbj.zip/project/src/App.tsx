import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { AuthProvider } from '@/context/AuthContext';
import { MetaProvider } from '@/context/MetaContext';
import { RouterProvider, useRoute } from '@/lib/router';
import HomePage from '@/pages/HomePage';
import ListPage from '@/pages/ListPage';
import PostItemPage from '@/pages/PostItemPage';
import ItemDetailPage from '@/pages/ItemDetailPage';
import AuthPage from '@/pages/AuthPage';
import MyPostsPage from '@/pages/MyPostsPage';
import NotFoundPage from '@/pages/NotFoundPage';

function Routes() {
  const { segments } = useRoute();

  // Routes:
  //   /                       -> Home
  //   /lost                   -> ListPage lost
  //   /found                  -> ListPage found
  //   /post/lost              -> PostItemPage lost
  //   /post/found             -> PostItemPage found
  //   /items/:id              -> ItemDetailPage
  //   /login                  -> AuthPage login
  //   /register               -> AuthPage register
  //   /my-posts               -> MyPostsPage
  if (segments.length === 0) return <HomePage />;
  const [first, second, third] = segments;

  if (first === 'lost') return <ListPage type="lost" />;
  if (first === 'found') return <ListPage type="found" />;
  if (first === 'post' && (second === 'lost' || second === 'found'))
    return <PostItemPage type={second} />;
  if (first === 'items' && second) return <ItemDetailPage id={second} />;
  if (first === 'login') return <AuthPage mode="login" />;
  if (first === 'register') return <AuthPage mode="register" />;
  if (first === 'my-posts') return <MyPostsPage />;
  void third;
  return <NotFoundPage />;
}

export default function App() {
  return (
    <RouterProvider>
      <MetaProvider>
        <AuthProvider>
          <div className="flex min-h-screen flex-col">
            <Navbar />
            <main className="flex-1">
              <Routes />
            </main>
            <Footer />
          </div>
        </AuthProvider>
      </MetaProvider>
    </RouterProvider>
  );
}
