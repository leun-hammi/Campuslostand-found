// ---------------------------------------------------------------------------
// API client for the Lost & Found app.
//
// Right now every method resolves against an in-memory mock store seeded with
// realistic sample data (see mockData.ts). The signatures are deliberately
// shaped to match a typical Java/Spring REST API so that switching to the real
// backend is a drop-in change: replace the function bodies with `fetch()`
// calls to your endpoints and keep the return types the same.
//
// Suggested Java endpoints (for later):
//   GET    /api/items?type=lost|found&category=&location=&q=&sort=
//   GET    /api/items/:id
//   POST   /api/items            (auth) create a lost/found listing
//   PATCH  /api/items/:id        (auth) update own listing
//   DELETE /api/items/:id        (auth) delete own listing
//   GET    /api/items/me         (auth) current user's listings
//   POST   /api/auth/login       { email, password } -> { token, user }
//   POST   /api/auth/register    { name, email, password } -> { token, user }
//   GET    /api/meta             -> { categories, locations }
// ---------------------------------------------------------------------------

import { CATEGORIES, LOCATIONS, SAMPLE_ITEMS, locationName } from './mockData';
import type {
  CampusLocation,
  ItemCategory,
  ItemFilters,
  ItemStatus,
  ListingType,
  LostItem,
  User,
} from './types';

// A tiny artificial latency so loading states are visible during development.
// Remove (set to 0) once the real backend is wired up.
const MOCK_LATENCY_MS = 280;
const delay = <T>(value: T, ms = MOCK_LATENCY_MS): Promise<T> =>
  new Promise((resolve) => setTimeout(() => resolve(value), ms));

// In-memory mutable store. Seeded once at module load. This persists for the
// lifetime of the browser session and is shared across all callers — so posts
// and edits show up immediately elsewhere in the UI.
let store: LostItem[] = [...SAMPLE_ITEMS];

// Auth is mocked locally and intentionally NOT persisted. The real session will
// come from the Java backend (e.g. a JWT). See auth.ts for the React context.
let currentUser: User | null = null;

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

function applyFilters(items: LostItem[], filters: ItemFilters = {}): LostItem[] {
  const q = filters.query?.trim().toLowerCase();
  let out = items;
  if (q) {
    out = out.filter((i) =>
      [i.name, i.description, i.locationName, i.category]
        .join(' ')
        .toLowerCase()
        .includes(q),
    );
  }
  if (filters.category && filters.category !== 'all') {
    out = out.filter((i) => i.category === filters.category);
  }
  if (filters.locationId && filters.locationId !== 'all') {
    out = out.filter((i) => i.locationId === filters.locationId);
  }
  switch (filters.sort) {
    case 'oldest':
      out = [...out].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      break;
    case 'date':
      out = [...out].sort((a, b) => b.date.localeCompare(a.date));
      break;
    case 'newest':
    default:
      out = [...out].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      break;
  }
  return out;
}

export const api = {
  // -- meta ---------------------------------------------------------------
  getCategories(): Promise<ItemCategory[]> {
    return delay([...CATEGORIES]);
  },
  getLocations(): Promise<CampusLocation[]> {
    return delay([...LOCATIONS]);
  },

  // -- listings ----------------------------------------------------------
  listItems(type?: ListingType, filters: ItemFilters = {}): Promise<LostItem[]> {
    let items = store;
    if (type) items = items.filter((i) => i.type === type);
    return delay(applyFilters(items, filters));
  },

  listMyItems(ownerId: string): Promise<LostItem[]> {
    return delay(applyFilters(store.filter((i) => i.ownerId === ownerId)));
  },

  getRecentItems(limit = 6): Promise<LostItem[]> {
    const recent = [...store]
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, limit);
    return delay(recent);
  },

  getItem(id: string): Promise<LostItem | null> {
    return delay(store.find((i) => i.id === id) ?? null);
  },

  createItem(
    input: Omit<LostItem, 'id' | 'status' | 'createdAt' | 'locationName' | 'ownerId'> &
      Partial<Pick<LostItem, 'status' | 'ownerId'>>,
  ): Promise<LostItem> {
    const now = new Date().toISOString();
    const item: LostItem = {
      id: uid('itm'),
      status: 'open',
      createdAt: now,
      locationName: locationName(input.locationId),
      ownerId: currentUser?.id ?? input.ownerId ?? 'user-demo',
      ...input,
    };
    store = [item, ...store];
    return delay(item);
  },

  updateItem(
    id: string,
    patch: Partial<Omit<LostItem, 'id' | 'createdAt'>> & { locationId?: string },
  ): Promise<LostItem | null> {
    let updated: LostItem | null = null;
    store = store.map((i) => {
      if (i.id !== id) return i;
      const next: LostItem = {
        ...i,
        ...patch,
        locationName: patch.locationId ? locationName(patch.locationId) : i.locationName,
      };
      updated = next;
      return next;
    });
    return delay(updated);
  },

  setStatus(id: string, status: ItemStatus): Promise<LostItem | null> {
    return this.updateItem(id, { status });
  },

  deleteItem(id: string): Promise<boolean> {
    const before = store.length;
    store = store.filter((i) => i.id !== id);
    return delay(store.length < before);
  },

  // -- auth (mock) -------------------------------------------------------
  // NOTE: this does NOT create a real account. It only simulates the API
  // contract until the Java backend is connected.
  async login(email: string, _password: string): Promise<User> {
    const name = email
      .split('@')[0]
      .split(/[._-]/)
      .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
      .join(' ');
    const user: User = { id: 'user-demo', name: name || 'Student', email };
    currentUser = user;
    return delay(user);
  },

  async register(name: string, email: string, _password: string): Promise<User> {
    const user: User = { id: uid('user'), name, email };
    currentUser = user;
    return delay(user);
  },

  async getCurrentUser(): Promise<User | null> {
    return delay(currentUser, 80);
  },

  async logout(): Promise<void> {
    currentUser = null;
    return delay(undefined, 80);
  },
};

export type Api = typeof api;
