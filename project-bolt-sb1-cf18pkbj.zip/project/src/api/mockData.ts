import type { CampusLocation, ItemCategory, LostItem } from './types';

// Static reference data reused across the app. Keep these stable so the
// mock store can reference them by id; when the Java backend lands, these
// can become a single GET /meta call.

export const CATEGORIES: ItemCategory[] = [
  'Electronics',
  'Accessories',
  'Bags',
  'Clothing',
  'IDs & Cards',
  'Keys',
  'Books & Notes',
  'Other',
];

export const LOCATIONS: CampusLocation[] = [
  { id: 'loc-lib', name: 'Central Library', code: 'LIB' },
  { id: 'loc-union', name: 'Student Union', code: 'UNN' },
  { id: 'loc-eng', name: 'Engineering Hall', code: 'ENG' },
  { id: 'loc-sci', name: 'Science Building', code: 'SCI' },
  { id: 'loc-gym', name: 'Athletics Center', code: 'GYM' },
  { id: 'loc-dining', name: 'Dining Pavilion', code: 'DIN' },
  { id: 'loc-parking', name: 'North Parking Lot', code: 'LOT' },
  { id: 'loc-quad', name: 'Main Quad', code: 'QUD' },
  { id: 'loc-dorm', name: 'Riverside Dorms', code: 'DRM' },
  { id: 'loc-cafe', name: 'Campus Café', code: 'CAF' },
];

export function locationName(id: string): string {
  return LOCATIONS.find((l) => l.id === id)?.name ?? 'Unknown location';
}

// Realistic sample listings. Dates are ISO strings; createdAt is when the
// report was posted (used for "newest" sort), date is when it happened.
export const SAMPLE_ITEMS: LostItem[] = [
  {
    id: 'itm-001',
    type: 'lost',
    name: 'Blue keychain with car keys',
    category: 'Keys',
    description:
      'A small blue lanyard with three silver keys and a Toyota remote. Lost near the library entrance — really important, I need them to drive home.',
    imageUrl:
      'https://images.pexels.com/photos/67094/pexels-photo-67094.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-lib',
    locationName: 'Central Library',
    date: '2026-10-28',
    status: 'open',
    contactName: 'Maya Chen',
    contactEmail: 'maya.chen@northgate.edu',
    ownerId: 'user-demo',
    createdAt: '2026-10-28T09:12:00Z',
  },
  {
    id: 'itm-002',
    type: 'found',
    name: 'Brown leather wallet',
    category: 'Accessories',
    description:
      'Found a brown leather wallet on a bench outside the Student Union. No cash inside, but there are a student ID and a couple of cards. Held at the Union info desk.',
    imageUrl:
      'https://images.pexels.com/photos/7085786/pexels-photo-7085786.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-union',
    locationName: 'Student Union',
    date: '2026-10-27',
    status: 'open',
    contactName: 'Devon Park',
    contactEmail: 'devon.park@northgate.edu',
    ownerId: 'user-other',
    createdAt: '2026-10-27T16:40:00Z',
  },
  {
    id: 'itm-003',
    type: 'found',
    name: 'Black backpack',
    category: 'Bags',
    description:
      'Black laptop backpack left in Engineering Hall, room 204. Name tag inside reads "R. Okafor". Currently kept at the engineering office.',
    imageUrl:
      'https://images.pexels.com/photos/7683617/pexels-photo-7683617.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-eng',
    locationName: 'Engineering Hall',
    date: '2026-10-26',
    status: 'open',
    contactName: 'Priya Nair',
    contactEmail: 'priya.nair@northgate.edu',
    ownerId: 'user-other',
    createdAt: '2026-10-26T11:05:00Z',
  },
  {
    id: 'itm-004',
    type: 'lost',
    name: 'Reusable water bottle',
    category: 'Other',
    description:
      'Clear reusable water bottle with a green cap and a "Northgate Athletics" sticker. Left somewhere in the Science Building after chem lab.',
    imageUrl:
      'https://images.pexels.com/photos/31699476/pexels-photo-31699476.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-sci',
    locationName: 'Science Building',
    date: '2026-10-25',
    status: 'open',
    contactName: 'Liam Rivera',
    contactEmail: 'liam.rivera@northgate.edu',
    ownerId: 'user-demo',
    createdAt: '2026-10-25T18:20:00Z',
  },
  {
    id: 'itm-005',
    type: 'found',
    name: 'Wireless headphones',
    category: 'Electronics',
    description:
      'Pair of black over-ear wireless headphones found on a desk in the Athletics Center lobby. Case not included. Turned in at the front desk.',
    imageUrl:
      'https://images.pexels.com/photos/210927/pexels-photo-210927.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-gym',
    locationName: 'Athletics Center',
    date: '2026-10-24',
    status: 'open',
    contactName: 'Sofia Mendes',
    contactEmail: 'sofia.mendes@northgate.edu',
    ownerId: 'user-other',
    createdAt: '2026-10-24T08:00:00Z',
  },
  {
    id: 'itm-006',
    type: 'lost',
    name: 'MacBook laptop',
    category: 'Electronics',
    description:
      '13" silver MacBook, stickers on the lid (a space cat and a "Powered by Coffee" decal). Last seen in the Dining Pavilion near the east windows.',
    imageUrl:
      'https://images.pexels.com/photos/265101/pexels-photo-265101.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-dining',
    locationName: 'Dining Pavilion',
    date: '2026-10-23',
    status: 'open',
    contactName: 'Ethan Walsh',
    contactEmail: 'ethan.walsh@northgate.edu',
    ownerId: 'user-demo',
    createdAt: '2026-10-23T13:45:00Z',
  },
  {
    id: 'itm-007',
    type: 'found',
    name: 'Black umbrella',
    category: 'Other',
    description:
      'Solid black folding umbrella found in the North Parking Lot near spot 38. A little damp. I can hold onto it for a few days.',
    imageUrl:
      'https://images.pexels.com/photos/5994460/pexels-photo-5994460.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-parking',
    locationName: 'North Parking Lot',
    date: '2026-10-22',
    status: 'open',
    contactName: 'Aaliyah Brooks',
    contactEmail: 'aaliyah.brooks@northgate.edu',
    ownerId: 'user-other',
    createdAt: '2026-10-22T19:30:00Z',
  },
  {
    id: 'itm-008',
    type: 'lost',
    name: 'Silver wristwatch',
    category: 'Accessories',
    description:
      'Silver wristwatch with a round face, left in the locker room at the Athletics Center. Sentimental value — a gift from my grandfather.',
    imageUrl:
      'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-gym',
    locationName: 'Athletics Center',
    date: '2026-10-21',
    status: 'open',
    contactName: 'Noah Schmidt',
    contactEmail: 'noah.schmidt@northgate.edu',
    ownerId: 'user-demo',
    createdAt: '2026-10-21T10:15:00Z',
  },
  {
    id: 'itm-009',
    type: 'found',
    name: 'Prescription eyeglasses',
    category: 'Accessories',
    description:
      'Tortoiseshell prescription glasses found on a library desk near the quiet study area. Folded on top of a physics textbook. Held at the library help desk.',
    imageUrl:
      'https://images.pexels.com/photos/13743898/pexels-photo-13743898.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-lib',
    locationName: 'Central Library',
    date: '2026-10-20',
    status: 'claimed',
    contactName: 'Grace Liu',
    contactEmail: 'grace.liu@northgate.edu',
    ownerId: 'user-other',
    createdAt: '2026-10-20T14:50:00Z',
  },
  {
    id: 'itm-010',
    type: 'lost',
    name: 'Student ID card',
    category: 'IDs & Cards',
    description:
      'Northgate student ID card (name: Jordan Tate) dropped somewhere on the Main Quad between the library and the café. Please contact me if found.',
    imageUrl:
      'https://images.pexels.com/photos/7821755/pexels-photo-7821755.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-quad',
    locationName: 'Main Quad',
    date: '2026-10-19',
    status: 'open',
    contactName: 'Jordan Tate',
    contactEmail: 'jordan.tate@northgate.edu',
    ownerId: 'user-demo',
    createdAt: '2026-10-19T07:55:00Z',
  },
  {
    id: 'itm-011',
    type: 'found',
    name: 'Lined notebook',
    category: 'Books & Notes',
    description:
      'A blue lined notebook with handwritten chemistry notes. Found at the Campus Café. No name on it but lots of MATH 201 scribbles.',
    imageUrl:
      'https://images.pexels.com/photos/7657382/pexels-photo-7657382.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-cafe',
    locationName: 'Campus Café',
    date: '2026-10-18',
    status: 'open',
    contactName: 'Marcus Webb',
    contactEmail: 'marcus.webb@northgate.edu',
    ownerId: 'user-other',
    createdAt: '2026-10-18T12:30:00Z',
  },
  {
    id: 'itm-012',
    type: 'lost',
    name: 'Phone (black, cracked screen)',
    category: 'Electronics',
    description:
      'Black smartphone with a cracked top-right corner of the screen. Last seen on a table in the Riverside Dorms lounge. Please reach out if anyone turns it in.',
    imageUrl:
      'https://images.pexels.com/photos/33039024/pexels-photo-33039024.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    locationId: 'loc-dorm',
    locationName: 'Riverside Dorms',
    date: '2026-10-17',
    status: 'open',
    contactName: 'Riya Patel',
    contactEmail: 'riya.patel@northgate.edu',
    ownerId: 'user-demo',
    createdAt: '2026-10-17T22:10:00Z',
  },
];
