// Shared domain types for the Lost & Found app.
// These mirror what a Java backend (e.g. Spring REST API) would return,
// so swapping the mock API client for a real one is a drop-in change.

export type ListingType = 'lost' | 'found';

export type ItemStatus = 'open' | 'claimed' | 'resolved';

export type ItemCategory =
  | 'Electronics'
  | 'Accessories'
  | 'Bags'
  | 'Clothing'
  | 'IDs & Cards'
  | 'Keys'
  | 'Books & Notes'
  | 'Other';

export interface CampusLocation {
  id: string;
  name: string;
  /** building / area short code shown on chips, e.g. "LIB" */
  code: string;
}

export interface LostItem {
  id: string;
  type: ListingType;
  name: string;
  category: ItemCategory;
  description: string;
  imageUrl: string;
  locationId: string;
  locationName: string;
  /** ISO date the item was lost/found (not the posted date). */
  date: string;
  status: ItemStatus;
  contactName: string;
  contactEmail: string;
  /** user id of the poster (set when backend is wired up). */
  ownerId: string;
  createdAt: string;
}

export interface ItemFilters {
  query?: string;
  category?: ItemCategory | 'all';
  locationId?: string | 'all';
  /** sort newest-first by default */
  sort?: 'newest' | 'oldest' | 'date';
}

export interface User {
  id: string;
  name: string;
  email: string;
}
