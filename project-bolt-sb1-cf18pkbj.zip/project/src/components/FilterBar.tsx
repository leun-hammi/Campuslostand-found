import { useMeta } from '@/context/MetaContext';
import type { ItemCategory, ItemFilters } from '@/api/types';
import { ChevronDown, Filter } from 'lucide-react';

interface Props {
  filters: ItemFilters;
  onChange: (next: ItemFilters) => void;
  /** Hide the query input (handled separately by SearchBar on some pages). */
  hideQuery?: boolean;
}

const SORTS: { value: NonNullable<ItemFilters['sort']>; label: string }[] = [
  { value: 'newest', label: 'Newest posts' },
  { value: 'date', label: 'Recent incidents' },
  { value: 'oldest', label: 'Oldest posts' },
];

export default function FilterBar({ filters, onChange, hideQuery }: Props) {
  const { categories, locations } = useMeta();

  const update = (patch: Partial<ItemFilters>) => onChange({ ...filters, ...patch });

  return (
    <div className="flex flex-wrap items-center gap-3">
      {!hideQuery && (
        <div className="relative flex-1 min-w-[200px]">
          <input
            type="text"
            value={filters.query ?? ''}
            onChange={(e) => update({ query: e.target.value })}
            placeholder="Search by name, keyword, or place…"
            className="input-base"
            aria-label="Search items"
          />
        </div>
      )}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter className="hidden h-4 w-4 text-royal-400 sm:block" />
          <div className="relative">
            <select
              value={filters.category ?? 'all'}
              onChange={(e) =>
                update({ category: e.target.value as ItemCategory | 'all' })
              }
              className="input-base appearance-none pr-9"
              aria-label="Filter by category"
            >
              <option value="all">All categories</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-royal-400" />
          </div>
        </div>
        <div className="relative">
          <select
            value={filters.locationId ?? 'all'}
            onChange={(e) => update({ locationId: e.target.value })}
            className="input-base appearance-none pr-9"
            aria-label="Filter by location"
          >
            <option value="all">All locations</option>
            {locations.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-royal-400" />
        </div>
        <div className="relative">
          <select
            value={filters.sort ?? 'newest'}
            onChange={(e) => update({ sort: e.target.value as ItemFilters['sort'] })}
            className="input-base appearance-none pr-9"
            aria-label="Sort items"
          >
            {SORTS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-royal-400" />
        </div>
      </div>
    </div>
  );
}
