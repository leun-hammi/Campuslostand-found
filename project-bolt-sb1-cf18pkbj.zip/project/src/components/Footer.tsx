import { Compass, Heart } from 'lucide-react';
import { Link } from '@/lib/router';

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-royal-100 bg-white">
      <div className="container-app py-10">
        <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-royal-600 text-white shadow-sm">
              <Compass className="h-5 w-5" />
            </span>
            <div>
              <p className="font-display text-sm font-extrabold text-royal-900">
                Northgate Lost &amp; Found
              </p>
              <p className="text-xs text-royal-500">Campus Services · Student Union Building</p>
            </div>
          </div>
          <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm font-medium text-royal-500">
            <Link to="/lost" className="transition hover:text-royal-800">
              Lost Items
            </Link>
            <Link to="/found" className="transition hover:text-royal-800">
              Found Items
            </Link>
            <Link to="/post/lost" className="transition hover:text-royal-800">
              Report Lost
            </Link>
            <Link to="/post/found" className="transition hover:text-royal-800">
              Report Found
            </Link>
            <Link to="/my-posts" className="transition hover:text-royal-800">
              My Posts
            </Link>
          </nav>
        </div>
        <div className="mt-8 flex flex-col items-center justify-between gap-2 border-t border-royal-50 pt-6 text-xs text-royal-400 sm:flex-row">
          <p>© {new Date().getFullYear()} Northgate University. All rights reserved.</p>
          <p className="inline-flex items-center gap-1.5">
            Made with <Heart className="h-3.5 w-3.5 text-rose-400" /> by the Campus Services team
          </p>
        </div>
      </div>
    </footer>
  );
}
