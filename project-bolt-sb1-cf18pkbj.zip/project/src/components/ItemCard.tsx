import { Calendar, MapPin } from 'lucide-react';
import type { LostItem } from '@/api/types';
import { formatDate, STATUS_STYLES, TYPE_STYLES } from '@/lib/format';
import { Link } from '@/lib/router';

interface Props {
  item: LostItem;
}

export default function ItemCard({ item }: Props) {
  const status = STATUS_STYLES[item.status];
  const type = TYPE_STYLES[item.type];

  return (
    <Link
      to={`/items/${item.id}`}
      className="card group block overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-card-hover"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-royal-50">
        <img
          src={item.imageUrl}
          alt={item.name}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute left-3 top-3 flex gap-2">
          <span className={`chip ${type.className} shadow-sm`}>{type.label}</span>
        </div>
        <div className="absolute right-3 top-3">
          <span className={`chip ${status.className} shadow-sm`}>
            <span className={`h-1.5 w-1.5 rounded-full ${status.dot}`} />
            {status.label}
          </span>
        </div>
      </div>
      <div className="space-y-3 p-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-royal-400">
            {item.category}
          </p>
          <h3 className="mt-0.5 line-clamp-1 font-display text-base font-bold text-royal-950">
            {item.name}
          </h3>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-royal-500">
          <span className="inline-flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            {formatDate(item.date)}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5" />
            {item.locationName}
          </span>
        </div>
      </div>
    </Link>
  );
}
