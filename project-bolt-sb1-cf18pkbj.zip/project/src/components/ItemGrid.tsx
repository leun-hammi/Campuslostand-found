import { PackageSearch } from 'lucide-react';
import type { LostItem } from '@/api/types';
import ItemCard from './ItemCard';

interface Props {
  items: LostItem[];
  loading?: boolean;
  emptyTitle?: string;
  emptyMessage?: string;
}

function SkeletonCard() {
  return (
    <div className="card overflow-hidden">
      <div className="aspect-[4/3] animate-pulse bg-royal-100" />
      <div className="space-y-3 p-4">
        <div className="h-3 w-1/3 animate-pulse rounded bg-royal-100" />
        <div className="h-4 w-2/3 animate-pulse rounded bg-royal-100" />
        <div className="h-3 w-1/2 animate-pulse rounded bg-royal-100" />
      </div>
    </div>
  );
}

export default function ItemGrid({ items, loading, emptyTitle, emptyMessage }: Props) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="card flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-royal-50 text-royal-500">
          <PackageSearch className="h-7 w-7" />
        </span>
        <h3 className="font-display text-lg font-bold text-royal-900">
          {emptyTitle ?? 'No items found'}
        </h3>
        <p className="max-w-sm text-sm text-royal-500">
          {emptyMessage ?? 'Try adjusting your search or filters — the right listing may be posted soon.'}
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {items.map((item) => (
        <ItemCard key={item.id} item={item} />
      ))}
    </div>
  );
}
