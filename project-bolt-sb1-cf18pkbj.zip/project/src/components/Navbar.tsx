import { useState } from 'react';
import { Compass, LogIn, LogOut, Menu, PackageSearch, Plus, User, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Link, useNavigate, useRoute } from '@/lib/router';

function navItemClass(active: boolean) {
  return `rounded-lg px-3 py-2 text-sm font-semibold transition ${
    active ? 'bg-royal-100 text-royal-800' : 'text-royal-600 hover:bg-royal-50 hover:text-royal-800'
  }`;
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const route = useRoute();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const path = route.path;
  const isActive = (p: string) => (p === '/' ? path === '/' : path.startsWith(p));

  const handleLogout = async () => {
    await logout();
    setOpen(false);
    navigate('/');
  };

  const links = [
    { to: '/', label: 'Home' },
    { to: '/lost', label: 'Lost Items' },
    { to: '/found', label: 'Found Items' },
    { to: '/my-posts', label: 'My Posts' },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-royal-100/80 bg-white/85 backdrop-blur-lg">
      <nav className="container-app flex h-16 items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2.5" aria-label="Northgate Lost & Found home">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-royal-600 text-white shadow-sm">
            <Compass className="h-5 w-5" />
          </span>
          <span className="font-display text-lg font-extrabold tracking-tight text-royal-900">
            Northgate<span className="text-royal-500"> Lost&nbsp;&amp;&nbsp;Found</span>
          </span>
        </Link>

        <div className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className={navItemClass(isActive(l.to))}>
              {l.label}
            </Link>
          ))}
        </div>

        <div className="hidden items-center gap-2 md:flex">
          <Link to="/post/lost" className="btn-secondary !px-3 !py-2">
            <Plus className="h-4 w-4" /> Post Lost
          </Link>
          <Link to="/post/found" className="btn-primary !px-3 !py-2">
            <Plus className="h-4 w-4" /> Post Found
          </Link>
          {user ? (
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-2 rounded-xl bg-royal-50 px-3 py-2 text-sm font-semibold text-royal-700 ring-1 ring-royal-100">
                <User className="h-4 w-4" />
                <span className="max-w-[140px] truncate">{user.name}</span>
              </span>
              <button onClick={handleLogout} className="btn-ghost !px-3 !py-2" aria-label="Sign out">
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <Link to="/login" className="btn-primary !px-3 !py-2">
              <LogIn className="h-4 w-4" /> Sign in
            </Link>
          )}
        </div>

        <button
          className="grid h-10 w-10 place-items-center rounded-xl text-royal-700 hover:bg-royal-50 md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-royal-100 bg-white md:hidden">
          <div className="container-app space-y-1 py-3">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className={`block ${navItemClass(isActive(l.to))}`}
                onClick={() => setOpen(false)}
              >
                {l.label}
              </Link>
            ))}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <Link
                to="/post/lost"
                onClick={() => setOpen(false)}
                className="btn-secondary justify-center"
              >
                <Plus className="h-4 w-4" /> Post Lost
              </Link>
              <Link
                to="/post/found"
                onClick={() => setOpen(false)}
                className="btn-primary justify-center"
              >
                <Plus className="h-4 w-4" /> Post Found
              </Link>
            </div>
            {user ? (
              <button
                onClick={handleLogout}
                className="btn-ghost mt-1 w-full justify-center"
              >
                <LogOut className="h-4 w-4" /> Sign out, {user.name.split(' ')[0]}
              </button>
            ) : (
              <Link
                to="/login"
                onClick={() => setOpen(false)}
                className="btn-ghost mt-1 w-full justify-center"
              >
                <PackageSearch className="h-4 w-4" /> Sign in
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
