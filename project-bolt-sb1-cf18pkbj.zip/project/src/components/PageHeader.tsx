interface Props {
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}

export default function PageHeader({ title, subtitle, children }: Props) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="font-display text-3xl font-extrabold tracking-tight text-royal-950 text-balance">
          {title}
        </h1>
        {subtitle && <p className="mt-2 max-w-2xl text-royal-500">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}
