import type { ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';
import { useEffect } from 'react';

type Tone = 'success' | 'error' | 'info' | 'warning';

const TONES: Record<Tone, { ring: string; icon: ReactNode }> = {
  success: {
    ring: 'bg-emerald-50 text-emerald-800 ring-emerald-200',
    icon: <CheckCircle2 className="h-5 w-5 text-emerald-500" />,
  },
  error: {
    ring: 'bg-rose-50 text-rose-800 ring-rose-200',
    icon: <AlertTriangle className="h-5 w-5 text-rose-500" />,
  },
  info: {
    ring: 'bg-royal-50 text-royal-800 ring-royal-200',
    icon: <Info className="h-5 w-5 text-royal-500" />,
  },
  warning: {
    ring: 'bg-amber-50 text-amber-800 ring-amber-200',
    icon: <AlertTriangle className="h-5 w-5 text-amber-500" />,
  },
};

interface Props {
  tone?: Tone;
  message: string;
  onClose?: () => void;
  className?: string;
}

export default function Banner({ tone = 'info', message, onClose, className = '' }: Props) {
  useEffect(() => {
    if (!onClose) return;
    const t = setTimeout(onClose, 5000);
    return () => clearTimeout(t);
  }, [onClose]);

  return (
    <div
      className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium ring-1 ${TONES[tone].ring} ${className}`}
      role="status"
    >
      <span className="shrink-0">{TONES[tone].icon}</span>
      <span className="flex-1">{message}</span>
      {onClose && (
        <button
          onClick={onClose}
          className="rounded-md p-1 opacity-70 transition hover:bg-black/5 hover:opacity-100"
          aria-label="Dismiss"
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
