import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { api } from '@/api/client';
import type { CampusLocation, ItemCategory } from '@/api/types';

// Reference data (categories + campus locations) shared across the app.
// Loaded once and cached so every page/filter can read from it synchronously.

interface MetaContextValue {
  categories: ItemCategory[];
  locations: CampusLocation[];
  loading: boolean;
}

const MetaContext = createContext<MetaContextValue | undefined>(undefined);

export function MetaProvider({ children }: { children: ReactNode }) {
  const [categories, setCategories] = useState<ItemCategory[]>([]);
  const [locations, setLocations] = useState<CampusLocation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    Promise.all([api.getCategories(), api.getLocations()]).then(([c, l]) => {
      if (!active) return;
      setCategories(c);
      setLocations(l);
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, []);

  const value = useMemo(() => ({ categories, locations, loading }), [categories, locations, loading]);
  return <MetaContext.Provider value={value}>{children}</MetaContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useMeta(): MetaContextValue {
  const ctx = useContext(MetaContext);
  if (!ctx) throw new Error('useMeta must be used within a MetaProvider');
  return ctx;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useLocationName(): (id: string) => string {
  const { locations } = useMeta();
  return useCallback(
    (id: string) => locations.find((l) => l.id === id)?.name ?? 'Unknown location',
    [locations],
  );
}
