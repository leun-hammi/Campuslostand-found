import type { ItemStatus, ListingType } from '@/api/types';

export function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function relativeDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const diff = Date.now() - d.getTime();
  const days = Math.floor(diff / 86_400_000);
  if (days <= 0) return 'today';
  if (days === 1) return 'yesterday';
  if (days < 7) return `${days} days ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  return formatDate(iso);
}

export const STATUS_STYLES: Record<ItemStatus, { label: string; className: string; dot: string }> = {
  open: {
    label: 'Open',
    className: 'bg-emerald-100 text-emerald-700',
    dot: 'bg-emerald-500',
  },
  claimed: {
    label: 'Claimed',
    className: 'bg-amber-100 text-amber-700',
    dot: 'bg-amber-500',
  },
  resolved: {
    label: 'Resolved',
    className: 'bg-royal-100 text-royal-700',
    dot: 'bg-royal-500',
  },
};

export const TYPE_STYLES: Record<ListingType, { label: string; className: string }> = {
  lost: { label: 'Lost', className: 'bg-rose-100 text-rose-700' },
  found: { label: 'Found', className: 'bg-emerald-100 text-emerald-700' },
};
