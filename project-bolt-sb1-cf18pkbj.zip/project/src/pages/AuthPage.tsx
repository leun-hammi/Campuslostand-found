import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import Banner from '@/components/ui/Banner';
import Button from '@/components/ui/Button';
import { Link, useNavigate } from '@/lib/router';
import { Compass, Lock, LogIn } from 'lucide-react';

type Mode = 'login' | 'register';

interface Props {
  mode: Mode;
}

const COPY: Record<Mode, { title: string; subtitle: string; cta: string; toggleTo: string; toggleLabel: string; toggleHint: string }> = {
  login: {
    title: 'Welcome back',
    subtitle: 'Sign in to manage your posts and claims across campus.',
    cta: 'Sign in',
    toggleTo: '/register',
    toggleLabel: 'Create an account',
    toggleHint: "Don't have an account?",
  },
  register: {
    title: 'Create your account',
    subtitle: 'Join Northgate Lost & Found to post and track your listings.',
    cta: 'Create account',
    toggleTo: '/login',
    toggleLabel: 'Sign in instead',
    toggleHint: 'Already have an account?',
  },
};

export default function AuthPage({ mode }: Props) {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const copy = COPY[mode];

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (mode === 'register' && name.trim().length < 2) {
      setError('Please enter your full name.');
      return;
    }
    if (!email.trim() || !password) {
      setError('Please enter your email and password.');
      return;
    }
    setSubmitting(true);
    try {
      if (mode === 'login') {
        await login(email.trim(), password);
      } else {
        await register(name.trim(), email.trim(), password);
      }
      navigate('/my-posts');
    } catch {
      setError('Something went wrong. Please try again.');
      setSubmitting(false);
    }
  };

  return (
    <div className="relative overflow-hidden">
      <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-royal-200/40 blur-3xl" />
      <div className="container-app relative flex min-h-[calc(100vh-4rem)] items-center justify-center py-14">
        <div className="grid w-full max-w-4xl overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-royal-950/5 md:grid-cols-2">
          {/* Brand panel */}
          <div className="relative hidden flex-col justify-between bg-gradient-to-br from-royal-700 to-royal-900 p-8 text-white md:flex">
            <div>
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/15">
                <Compass className="h-6 w-6" />
              </span>
              <h2 className="mt-6 font-display text-2xl font-extrabold leading-tight">
                Northgate Lost &amp; Found
              </h2>
              <p className="mt-3 text-sm text-royal-100/80">
                The trusted place to report, search, and reclaim lost items across campus.
              </p>
            </div>
            <div className="space-y-3 text-sm text-royal-100/90">
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-accent-400" /> Track all your posts in one dashboard
              </div>
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-accent-400" /> Contact finders &amp; claim safely
              </div>
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-accent-400" /> Search across 10 campus locations
              </div>
            </div>
          </div>

          {/* Form panel */}
          <div className="p-8 sm:p-10">
            <h1 className="font-display text-2xl font-extrabold text-royal-950">{copy.title}</h1>
            <p className="mt-1.5 text-sm text-royal-500">{copy.subtitle}</p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              {mode === 'register' && (
                <div>
                  <label className="label-base" htmlFor="name">
                    Full name
                  </label>
                  <input
                    id="name"
                    className="input-base"
                    placeholder="Jordan Tate"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoComplete="name"
                  />
                </div>
              )}
              <div>
                <label className="label-base" htmlFor="email">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  className="input-base"
                  placeholder="you@northgate.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
              </div>
              <div>
                <label className="label-base" htmlFor="password">
                  Password
                </label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-royal-400" />
                  <input
                    id="password"
                    type="password"
                    className="input-base pl-9"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  />
                </div>
              </div>

              {error && <Banner tone="error" message={error} onClose={() => setError(null)} />}

              <Button type="submit" loading={submitting} className="w-full">
                <LogIn className="h-4 w-4" /> {copy.cta}
              </Button>
            </form>

            <p className="mt-6 text-center text-sm text-royal-500">
              {copy.toggleHint}{' '}
              <Link to={copy.toggleTo} className="font-bold text-royal-700 hover:underline">
                {copy.toggleLabel}
              </Link>
            </p>
            <p className="mt-4 rounded-xl bg-royal-50 p-3 text-center text-xs text-royal-400">
              Accounts are simulated until your backend is connected — no real password is stored.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
