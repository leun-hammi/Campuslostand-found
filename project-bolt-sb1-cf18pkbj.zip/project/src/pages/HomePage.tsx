import { useEffect, useState } from 'react';
import { ArrowRight, Compass, HandHeart, Search, ShieldCheck } from 'lucide-react';
import { api } from '@/api/client';
import type { LostItem } from '@/api/types';
import SearchBar from '@/components/SearchBar';
import ItemGrid from '@/components/ItemGrid';
import { Link } from '@/lib/router';
import { useNavigate } from '@/lib/router';

const STATS = [
  { label: 'Items reunited', value: '1,200+' },
  { label: 'Active listings', value: '340' },
  { label: 'Campus locations', value: '10' },
  { label: 'Avg. match time', value: '2 days' },
];

export default function HomePage() {
  const [items, setItems] = useState<LostItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    api.getRecentItems(8).then((recent) => {
      if (active) {
        setItems(recent);
        setLoading(false);
      }
    });
    return () => {
      active = false;
    };
  }, []);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(query ? `/lost?q=${encodeURIComponent(query)}` : '/lost');
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-royal-50 to-white">
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-royal-200/40 blur-3xl" />
        <div className="pointer-events-none absolute -left-20 top-40 h-64 w-64 rounded-full bg-accent-200/40 blur-3xl" />
        <div className="container-app relative py-16 sm:py-24">
          <div className="mx-auto max-w-3xl text-center">
            <span className="chip mx-auto mb-5 bg-royal-100 text-royal-700">
              <Compass className="h-3.5 w-3.5" /> Northgate University · Campus Services
            </span>
            <h1 className="font-display text-4xl font-extrabold leading-tight tracking-tight text-royal-950 text-balance sm:text-5xl">
              Lost something? Found something?
              <span className="block text-royal-600">Let's get it back to its owner.</span>
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg text-royal-500 text-balance">
              The official campus Lost &amp; Found. Report a lost item, post something you found, and
              search across every building — all in one place.
            </p>

            <form
              onSubmit={submitSearch}
              className="mx-auto mt-8 flex max-w-2xl flex-col gap-3 sm:flex-row"
            >
              <SearchBar value={query} onChange={setQuery} className="flex-1" />
              <button type="submit" className="btn-primary sm:px-6">
                <Search className="h-4 w-4" /> Search
              </button>
            </form>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <Link to="/post/lost" className="btn-secondary">
                <HandHeart className="h-4 w-4" /> Report a lost item
              </Link>
              <Link to="/post/found" className="btn-ghost">
                Post a found item <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          {/* Stats strip */}
          <div className="mx-auto mt-14 grid max-w-4xl grid-cols-2 gap-4 sm:grid-cols-4">
            {STATS.map((s) => (
              <div
                key={s.label}
                className="card flex flex-col items-center gap-1 px-4 py-5 text-center"
              >
                <span className="font-display text-2xl font-extrabold text-royal-700">
                  {s.value}
                </span>
                <span className="text-xs font-medium text-royal-500">{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="container-app py-16">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              icon: <Search className="h-6 w-6" />,
              title: 'Search the listings',
              body: 'Browse lost and found items across campus and filter by category, date, and location.',
            },
            {
              icon: <HandHeart className="h-6 w-6" />,
              title: 'Report in seconds',
              body: 'Post a lost or found item with a photo and contact details so others can reach you.',
            },
            {
              icon: <ShieldCheck className="h-6 w-6" />,
              title: 'Claim safely',
              body: 'Use the claim button to contact the finder and coordinate a pickup on campus.',
            },
          ].map((card) => (
            <div key={card.title} className="card p-6">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-royal-50 text-royal-600">
                {card.icon}
              </span>
              <h3 className="mt-4 font-display text-lg font-bold text-royal-900">{card.title}</h3>
              <p className="mt-1.5 text-sm text-royal-500">{card.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Recent listings */}
      <section className="container-app pb-20">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl font-extrabold tracking-tight text-royal-950">
              Recently posted
            </h2>
            <p className="mt-1 text-sm text-royal-500">
              The latest items reported across campus this week.
            </p>
          </div>
          <Link
            to="/lost"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-royal-600 hover:text-royal-800"
          >
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <ItemGrid items={items} loading={loading} />
      </section>
    </div>
  );
}
