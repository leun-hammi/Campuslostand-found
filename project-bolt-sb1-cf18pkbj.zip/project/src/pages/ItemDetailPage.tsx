import { useEffect, useState } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/context/AuthContext';
import type { LostItem } from '@/api/types';
import Banner from '@/components/ui/Banner';
import Button from '@/components/ui/Button';
import { formatDate, relativeDate, STATUS_STYLES, TYPE_STYLES } from '@/lib/format';
import { Link, useNavigate } from '@/lib/router';
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  Mail,
  MapPin,
  MessageCircle,
  Tag,
  User as UserIcon,
} from 'lucide-react';

interface Props {
  id: string;
}

export default function ItemDetailPage({ id }: Props) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [item, setItem] = useState<LostItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [claimed, setClaimed] = useState(false);
  const [banner, setBanner] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    api.getItem(id).then((it) => {
      if (!active) return;
      setItem(it);
      setClaimed(it?.status === 'claimed');
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [id]);

  const handleClaim = async () => {
    if (!item) return;
    setClaiming(true);
    const updated = await api.setStatus(item.id, 'claimed');
    if (updated) {
      setItem(updated);
      setClaimed(true);
      setBanner('Marked as claimed. Reach out to the contact below to arrange pickup.');
    }
    setClaiming(false);
  };

  if (loading) {
    return (
      <div className="container-app py-20">
        <div className="card animate-pulse overflow-hidden">
          <div className="aspect-[16/9] bg-royal-100" />
          <div className="space-y-4 p-8">
            <div className="h-6 w-1/3 rounded bg-royal-100" />
            <div className="h-10 w-2/3 rounded bg-royal-100" />
            <div className="h-24 w-full rounded bg-royal-100" />
          </div>
        </div>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="container-app py-20">
        <div className="card mx-auto max-w-md p-10 text-center">
          <h2 className="font-display text-xl font-bold text-royal-900">Item not found</h2>
          <p className="mt-2 text-sm text-royal-500">
            This listing may have been deleted or the link is incorrect.
          </p>
          <Link to="/lost" className="btn-primary mt-6">
            <ArrowLeft className="h-4 w-4" /> Back to listings
          </Link>
        </div>
      </div>
    );
  }

  const status = STATUS_STYLES[item.status];
  const type = TYPE_STYLES[item.type];
  const isOwner = user?.id === item.ownerId;
  const mailSubject = encodeURIComponent(`Lost & Found: ${item.name}`);
  const mailBody = encodeURIComponent(
    `Hi ${item.contactName},\n\nI believe the "${item.name}" you listed on Northgate Lost & Found is mine. Could we arrange to meet so I can verify and pick it up?\n\nThanks,\n${user?.name ?? ''}`,
  );
  const mailto = `mailto:${item.contactEmail}?subject=${mailSubject}&body=${mailBody}`;

  return (
    <div className="container-app py-10">
      <Link
        to={item.type === 'lost' ? '/lost' : '/found'}
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-semibold text-royal-500 transition hover:text-royal-800"
      >
        <ArrowLeft className="h-4 w-4" /> Back to {item.type} items
      </Link>

      {banner && (
        <Banner tone="success" message={banner} onClose={() => setBanner(null)} className="mb-6" />
      )}

      <div className="grid gap-8 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <div className="card overflow-hidden">
            <div className="relative aspect-[16/10] bg-royal-50">
              <img src={item.imageUrl} alt={item.name} className="h-full w-full object-cover" />
              <div className="absolute left-4 top-4 flex gap-2">
                <span className={`chip ${type.className} shadow-sm`}>{type.label}</span>
                <span className={`chip ${status.className} shadow-sm`}>
                  <span className={`h-1.5 w-1.5 rounded-full ${status.dot}`} />
                  {status.label}
                </span>
              </div>
            </div>
            <div className="space-y-6 p-6">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-royal-400">
                  {item.category}
                </p>
                <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight text-royal-950 text-balance">
                  {item.name}
                </h1>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <InfoRow icon={<Calendar className="h-4 w-4" />} label={item.type === 'lost' ? 'Lost on' : 'Found on'} value={formatDate(item.date)} />
                <InfoRow icon={<MapPin className="h-4 w-4" />} label="Location" value={item.locationName} />
                <InfoRow icon={<Tag className="h-4 w-4" />} label="Category" value={item.category} />
                <InfoRow icon={<Calendar className="h-4 w-4" />} label="Posted" value={relativeDate(item.createdAt)} />
              </div>

              <div>
                <h3 className="mb-2 font-display text-sm font-bold uppercase tracking-wide text-royal-500">
                  Description
                </h3>
                <p className="whitespace-pre-line text-royal-700">{item.description}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="card sticky top-24 space-y-5 p-6">
            <div>
              <h3 className="font-display text-sm font-bold uppercase tracking-wide text-royal-500">
                Posted by
              </h3>
              <div className="mt-3 flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-royal-100 text-royal-700">
                  <UserIcon className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-semibold text-royal-900">{item.contactName}</p>
                  <p className="text-sm text-royal-500">{item.contactEmail}</p>
                </div>
              </div>
            </div>

            <div className="h-px bg-royal-50" />

            {claimed ? (
              <div className="flex flex-col items-center gap-3 rounded-2xl bg-emerald-50 p-5 text-center ring-1 ring-emerald-200">
                <CheckCircle2 className="h-8 w-8 text-emerald-500" />
                <div>
                  <p className="font-display font-bold text-emerald-800">Claim in progress</p>
                  <p className="text-sm text-emerald-700">
                    Contact the poster to confirm and arrange pickup.
                  </p>
                </div>
                <a href={mailto} className="btn-secondary w-full justify-center">
                  <Mail className="h-4 w-4" /> Email {item.contactName.split(' ')[0]}
                </a>
              </div>
            ) : (
              <div className="space-y-3">
                {item.type === 'lost' ? (
                  <p className="text-sm text-royal-500">
                    Think you found this item? Let the owner know and mark it as claimed.
                  </p>
                ) : (
                  <p className="text-sm text-royal-500">
                    Believe this is yours? Claim it and reach out to arrange pickup.
                  </p>
                )}
                {isOwner ? (
                  <div className="rounded-xl bg-royal-50 p-4 text-sm font-medium text-royal-700 ring-1 ring-royal-100">
                    This is your listing. Manage it from{' '}
                    <Link to="/my-posts" className="font-bold underline">
                      My Posts
                    </Link>
                    .
                  </div>
                ) : (
                  <>
                    <a href={mailto} className="btn-primary w-full justify-center">
                      <MessageCircle className="h-4 w-4" /> Contact poster
                    </a>
                    <Button
                      variant="secondary"
                      onClick={handleClaim}
                      loading={claiming}
                      className="w-full"
                    >
                      <CheckCircle2 className="h-4 w-4" /> Mark as claimed
                    </Button>
                  </>
                )}
              </div>
            )}

            <p className="text-center text-xs text-royal-400">
              Claims are simulated until accounts &amp; messaging are wired to your backend.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3 rounded-xl bg-royal-50/60 p-3">
      <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white text-royal-600 ring-1 ring-royal-100">
        {icon}
      </span>
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-royal-400">{label}</p>
        <p className="text-sm font-semibold text-royal-900">{value}</p>
      </div>
    </div>
  );
}
