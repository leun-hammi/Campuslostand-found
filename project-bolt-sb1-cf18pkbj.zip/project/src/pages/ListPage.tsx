import { useEffect, useMemo, useState } from 'react';
import { api } from '@/api/client';
import type { ItemFilters, ListingType, LostItem } from '@/api/types';
import FilterBar from '@/components/FilterBar';
import ItemGrid from '@/components/ItemGrid';
import PageHeader from '@/components/PageHeader';
import { Link, useRoute } from '@/lib/router';
import { Plus, Sparkles } from 'lucide-react';

interface Props {
  type: ListingType;
}

const COPY: Record<ListingType, {
  title: string;
  subtitle: string;
  emptyTitle: string;
  emptyMessage: string;
  postLabel: string;
  postTo: string;
}> = {
  lost: {
    title: 'Lost Items',
    subtitle:
      'Items reported missing by the Northgate community. Spot something of yours? Open the listing to claim it.',
    emptyTitle: 'No lost items match your search',
    emptyMessage: 'If you lost something, post it here so others can keep an eye out.',
    postLabel: 'Post a lost item',
    postTo: '/post/lost',
  },
  found: {
    title: 'Found Items',
    subtitle:
      'Things found around campus and turned in by fellow students. See something that is yours? Reach out to claim it.',
    emptyTitle: 'No found items match your search',
    emptyMessage: 'Found something? Post it here so the owner can find it.',
    postLabel: 'Post a found item',
    postTo: '/post/found',
  },
};

export default function ListPage({ type }: Props) {
  const [items, setItems] = useState<LostItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<ItemFilters>({ sort: 'newest' });
  const route = useRoute();

  // Read an optional `?q=` from the hash so the home search can deep-link here.
  useEffect(() => {
    const hash = window.location.hash.replace(/^#\/[^?]*/, '');
    const params = new URLSearchParams(hash.replace(/^\?/, ''));
    const q = params.get('q');
    if (q) setFilters((f) => ({ ...f, query: q }));
  }, [type, route.path]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    api.listItems(type, filters).then((rows) => {
      if (!active) return;
      setItems(rows);
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [type, filters]);

  const copy = COPY[type];

  const count = useMemo(() => items.length, [items]);

  return (
    <div className="container-app py-10">
      <PageHeader title={copy.title} subtitle={copy.subtitle}>
        <Link to={copy.postTo} className="btn-primary">
          <Plus className="h-4 w-4" /> {copy.postLabel}
        </Link>
      </PageHeader>

      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <FilterBar filters={filters} onChange={setFilters} />
        <span className="inline-flex items-center gap-1.5 text-sm font-medium text-royal-500">
          <Sparkles className="h-4 w-4 text-royal-400" />
          {count} {count === 1 ? 'item' : 'items'}
        </span>
      </div>

      <ItemGrid
        items={items}
        loading={loading}
        emptyTitle={copy.emptyTitle}
        emptyMessage={copy.emptyMessage}
      />
    </div>
  );
}
