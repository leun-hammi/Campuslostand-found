import { useEffect, useMemo, useState } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/context/AuthContext';
import type { ItemFilters, ItemStatus, LostItem } from '@/api/types';
import Banner from '@/components/ui/Banner';
import Button from '@/components/ui/Button';
import FilterBar from '@/components/FilterBar';
import ItemGrid from '@/components/ItemGrid';
import PageHeader from '@/components/PageHeader';
import { STATUS_STYLES, TYPE_STYLES } from '@/lib/format';
import { Link, useNavigate } from '@/lib/router';
import {
  ArrowLeft,
  CheckCircle2,
  PackageSearch,
  Plus,
  RotateCcw,
  Trash2,
} from 'lucide-react';

const STATUS_OPTIONS: ItemStatus[] = ['open', 'claimed', 'resolved'];

export default function MyPostsPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState<LostItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<ItemFilters>({ sort: 'newest' });
  const [statusFilter, setStatusFilter] = useState<ItemStatus | 'all'>('all');
  const [message, setMessage] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  // Until a real backend exists, we attribute all sample items to a demo
  // user so the dashboard has content to show. When the backend is wired,
  // this will resolve to the signed-in user's own posts.
  const ownerId = user?.id ?? 'user-demo';

  useEffect(() => {
    let active = true;
    setLoading(true);
    api.listMyItems(ownerId).then((rows) => {
      if (!active) return;
      setItems(rows);
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [ownerId]);

  const visible = useMemo(() => {
    let out = items;
    if (statusFilter !== 'all') out = out.filter((i) => i.status === statusFilter);
    const q = filters.query?.trim().toLowerCase();
    if (q) {
      out = out.filter((i) =>
        [i.name, i.description, i.locationName, i.category].join(' ').toLowerCase().includes(q),
      );
    }
    if (filters.category && filters.category !== 'all')
      out = out.filter((i) => i.category === filters.category);
    if (filters.locationId && filters.locationId !== 'all')
      out = out.filter((i) => i.locationId === filters.locationId);
    return out;
  }, [items, statusFilter, filters]);

  const handleStatus = async (id: string, status: ItemStatus) => {
    const updated = await api.setStatus(id, status);
    if (updated) {
      setItems((prev) => prev.map((i) => (i.id === id ? updated : i)));
      setMessage(`Listing marked as ${STATUS_STYLES[status].label.toLowerCase()}.`);
    }
  };

  const handleDelete = async (id: string) => {
    const ok = await api.deleteItem(id);
    if (ok) {
      setItems((prev) => prev.filter((i) => i.id !== id));
      setMessage('Listing deleted.');
      setConfirmId(null);
    }
  };

  if (!authLoading && !user) {
    return (
      <div className="container-app py-20">
        <div className="card mx-auto max-w-lg p-10 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-royal-50 text-royal-500">
            <PackageSearch className="h-7 w-7" />
          </span>
          <h2 className="mt-4 font-display text-xl font-bold text-royal-900">
            Sign in to manage your posts
          </h2>
          <p className="mt-2 text-sm text-royal-500">
            Once accounts are connected to your backend, your personal listings and claims will show up here.
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <Link to="/login" className="btn-primary">
              Sign in
            </Link>
            <Link to="/register" className="btn-secondary">
              Create account
            </Link>
          </div>
          <p className="mt-4 text-xs text-royal-400">
            For now the dashboard shows demo listings so you can preview the layout.
          </p>
          <Link
            to="/"
            className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-royal-500 hover:text-royal-800"
          >
            <ArrowLeft className="h-4 w-4" /> Back home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container-app py-10">
      <PageHeader
        title="My Posts"
        subtitle="Manage the items you've reported. Update their status, edit details, or remove a listing once it's resolved."
      >
        <div className="flex gap-2">
          <Link to="/post/lost" className="btn-secondary">
            <Plus className="h-4 w-4" /> Post lost
          </Link>
          <Link to="/post/found" className="btn-primary">
            <Plus className="h-4 w-4" /> Post found
          </Link>
        </div>
      </PageHeader>

      {message && <Banner tone="success" message={message} onClose={() => setMessage(null)} className="mb-6" />}

      {/* Status tabs */}
      <div className="mb-6 flex flex-wrap gap-2">
        {(['all', ...STATUS_OPTIONS] as const).map((s) => {
          const active = statusFilter === s;
          const label = s === 'all' ? 'All' : STATUS_STYLES[s].label;
          return (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`chip border transition ${
                active
                  ? 'border-royal-300 bg-royal-100 text-royal-800'
                  : 'border-royal-100 bg-white text-royal-500 hover:bg-royal-50'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {visible.length === 0 && !loading ? (
        <ItemGrid
          items={[]}
          emptyTitle="No posts here yet"
          emptyMessage="Report a lost or found item and it'll appear in your dashboard."
        />
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((item) => {
            const status = STATUS_STYLES[item.status];
            const type = TYPE_STYLES[item.type];
            return (
              <div key={item.id} className="card overflow-hidden">
                <div className="relative aspect-[4/3] overflow-hidden bg-royal-50">
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute left-3 top-3 flex gap-2">
                    <span className={`chip ${type.className} shadow-sm`}>{type.label}</span>
                  </div>
                  <div className="absolute right-3 top-3">
                    <span className={`chip ${status.className} shadow-sm`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${status.dot}`} />
                      {status.label}
                    </span>
                  </div>
                </div>
                <div className="space-y-4 p-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-royal-400">
                      {item.category} · {item.locationName}
                    </p>
                    <h3 className="mt-0.5 line-clamp-1 font-display text-base font-bold text-royal-950">
                      {item.name}
                    </h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {item.status !== 'claimed' && (
                      <Button
                        variant="secondary"
                        className="!px-3 !py-1.5 !text-xs"
                        onClick={() => handleStatus(item.id, 'claimed')}
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" /> Mark claimed
                      </Button>
                    )}
                    {item.status !== 'resolved' && (
                      <Button
                        variant="secondary"
                        className="!px-3 !py-1.5 !text-xs"
                        onClick={() => handleStatus(item.id, 'resolved')}
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" /> Resolve
                      </Button>
                    )}
                    {item.status !== 'open' && (
                      <Button
                        variant="ghost"
                        className="!px-3 !py-1.5 !text-xs"
                        onClick={() => handleStatus(item.id, 'open')}
                      >
                        <RotateCcw className="h-3.5 w-3.5" /> Reopen
                      </Button>
                    )}
                  </div>
                  <div className="flex items-center justify-between border-t border-royal-50 pt-3">
                    <Link
                      to={`/items/${item.id}`}
                      className="text-xs font-semibold text-royal-600 hover:text-royal-800"
                    >
                      View details
                    </Link>
                    {confirmId === item.id ? (
                      <span className="flex items-center gap-2">
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="chip bg-rose-100 text-rose-700 hover:bg-rose-200"
                        >
                          <Trash2 className="h-3.5 w-3.5" /> Confirm delete
                        </button>
                        <button
                          onClick={() => setConfirmId(null)}
                          className="text-xs font-medium text-royal-400 hover:text-royal-600"
                        >
                          Cancel
                        </button>
                      </span>
                    ) : (
                      <button
                        onClick={() => setConfirmId(item.id)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-rose-500 hover:text-rose-700"
                      >
                        <Trash2 className="h-3.5 w-3.5" /> Delete
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
