import { Compass } from 'lucide-react';
import { Link } from '@/lib/router';

export default function NotFoundPage() {
  return (
    <div className="container-app flex min-h-[60vh] items-center justify-center py-20">
      <div className="card max-w-md p-10 text-center">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-royal-50 text-royal-500">
          <Compass className="h-7 w-7" />
        </span>
        <h1 className="mt-4 font-display text-2xl font-extrabold text-royal-950">
          Page not found
        </h1>
        <p className="mt-2 text-sm text-royal-500">
          The page you're looking for may have been moved or never existed.
        </p>
        <Link to="/" className="btn-primary mt-6">
          Back to home
        </Link>
      </div>
    </div>
  );
}
