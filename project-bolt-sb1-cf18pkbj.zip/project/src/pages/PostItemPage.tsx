import { useState } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/context/AuthContext';
import { useMeta } from '@/context/MetaContext';
import type { ItemCategory, ListingType } from '@/api/types';
import Button from '@/components/ui/Button';
import Banner from '@/components/ui/Banner';
import PageHeader from '@/components/PageHeader';
import { useNavigate } from '@/lib/router';
import { Camera, ChevronDown, ImagePlus } from 'lucide-react';

interface Props {
  type: ListingType;
}

const COPY: Record<ListingType, { title: string; subtitle: string; cta: string }> = {
  lost: {
    title: 'Report a Lost Item',
    subtitle:
      "Tell us what you lost and where you last saw it. The more detail you add, the better the chances someone spots it.",
    cta: 'Post lost item',
  },
  found: {
    title: 'Report a Found Item',
    subtitle:
      "Thanks for turning something in. Add a few details so the owner can recognize it and reach out to claim it.",
    cta: 'Post found item',
  },
};

const DEFAULT_IMAGE =
  'https://images.pexels.com/photos/172756/pexels-photo-172756.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function PostItemPage({ type }: Props) {
  const { user } = useAuth();
  const { categories, locations } = useMeta();
  const navigate = useNavigate();
  const copy = COPY[type];

  const [name, setName] = useState('');
  const [category, setCategory] = useState<ItemCategory>(categories[0] ?? 'Other');
  const [locationId, setLocationId] = useState(locations[0]?.id ?? '');
  const [date, setDate] = useState(todayISO());
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [contactName, setContactName] = useState(user?.name ?? '');
  const [contactEmail, setContactEmail] = useState(user?.email ?? '');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim() || !description.trim() || !locationId || !date) {
      setError('Please fill in the item name, description, location, and date.');
      return;
    }
    setSubmitting(true);
    try {
      const created = await api.createItem({
        type,
        name: name.trim(),
        category,
        description: description.trim(),
        imageUrl: imageUrl.trim() || DEFAULT_IMAGE,
        locationId,
        date,
        contactName: contactName.trim() || user?.name || 'Anonymous',
        contactEmail: contactEmail.trim() || user?.email || 'unknown@northgate.edu',
      });
      navigate(`/items/${created.id}`);
    } catch {
      setError('Something went wrong while posting. Please try again.');
      setSubmitting(false);
    }
  };

  return (
    <div className="container-app py-10">
      <PageHeader title={copy.title} subtitle={copy.subtitle} />

      {!user && (
        <Banner
          tone="info"
          message="You can post as a guest for now. Sign in once accounts are connected to your backend to track your posts."
          className="mb-6"
        />
      )}

      <form onSubmit={handleSubmit} className="grid gap-6 lg:grid-cols-3">
        <div className="card space-y-5 p-6 lg:col-span-2">
          <div>
            <label className="label-base" htmlFor="name">
              Item name
            </label>
            <input
              id="name"
              className="input-base"
              placeholder="e.g. Blue keychain with car keys"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="label-base" htmlFor="category">
                Category
              </label>
              <div className="relative">
                <select
                  id="category"
                  className="input-base appearance-none pr-9"
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ItemCategory)}
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-royal-400" />
              </div>
            </div>
            <div>
              <label className="label-base" htmlFor="location">
                Location
              </label>
              <div className="relative">
                <select
                  id="location"
                  className="input-base appearance-none pr-9"
                  value={locationId}
                  onChange={(e) => setLocationId(e.target.value)}
                  required
                >
                  {locations.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-royal-400" />
              </div>
            </div>
          </div>

          <div>
            <label className="label-base" htmlFor="date">
              {type === 'lost' ? 'Date you lost it' : 'Date you found it'}
            </label>
            <input
              id="date"
              type="date"
              max={todayISO()}
              className="input-base"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="label-base" htmlFor="description">
              Description
            </label>
            <textarea
              id="description"
              rows={5}
              className="input-base resize-none"
              placeholder="Distinguishing features, color, contents, anything that helps someone recognize it…"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="space-y-6">
          <div className="card p-6">
            <label className="label-base">Photo</label>
            <div className="relative mt-2 aspect-[4/3] overflow-hidden rounded-xl bg-royal-50 ring-1 ring-royal-100">
              <img
                src={imageUrl.trim() || DEFAULT_IMAGE}
                alt="Item preview"
                className="h-full w-full object-cover"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-royal-950/30 to-transparent" />
              <div className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-royal-700">
                <ImagePlus className="h-3.5 w-3.5" /> Preview
              </div>
            </div>
            <div className="relative mt-3">
              <Camera className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-royal-400" />
              <input
                type="url"
                className="input-base pl-9"
                placeholder="Paste an image URL"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
              />
            </div>
            <p className="mt-2 text-xs text-royal-400">
              Paste a direct link to an image. A default placeholder is used if none is provided.
            </p>
          </div>

          <div className="card space-y-5 p-6">
            <h3 className="font-display text-sm font-bold uppercase tracking-wide text-royal-500">
              Contact details
            </h3>
            <div>
              <label className="label-base" htmlFor="contactName">
                Your name
              </label>
              <input
                id="contactName"
                className="input-base"
                placeholder="How should the owner address you?"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
              />
            </div>
            <div>
              <label className="label-base" htmlFor="contactEmail">
                Email
              </label>
              <input
                id="contactEmail"
                type="email"
                className="input-base"
                placeholder="you@northgate.edu"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
              />
            </div>
          </div>

          {error && <Banner tone="error" message={error} onClose={() => setError(null)} />}

          <Button type="submit" loading={submitting} className="w-full">
            {copy.cta}
          </Button>
          <p className="text-center text-xs text-royal-400">
            Posts are stored in a demo layer until your backend is connected.
          </p>
        </div>
      </form>
    </div>
  );
}
